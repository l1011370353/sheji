package com.huawei.android.hms.agent.push.handler;

import com.huawei.android.hms.agent.common.ICallbackCode;

/**
 * enableReceiveNormalMsg 回调
 */
public interface EnableReceiveNormalMsgHandler extends ICallbackCode {
}
